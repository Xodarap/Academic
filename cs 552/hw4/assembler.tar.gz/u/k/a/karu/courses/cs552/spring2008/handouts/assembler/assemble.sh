#!/bin/sh

file=$1;
java -classpath /u/k/a/karu/courses/cs552/spring2008/handouts/assembler Assemble $file

