public class DuplicateException extends Exception {}
