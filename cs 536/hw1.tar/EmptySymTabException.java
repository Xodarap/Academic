public class EmptySymTabException extends Exception {}
